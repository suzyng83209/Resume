# CV Template for XeLaTeX
I created a custom curriculum vitae class file (.cls). Look at the comments in cv-roald-example.tex to understand how it works. 

# Screenshot of cv-roald-example.pdf
![example](https://github.com/Roald87/xelatex-cv-roald/blob/master/cv-roald-example.png)
